#include <stdio.h>

int main(int argn, char* argv[])
{
	printf("\n\n");
	
	printf("Hello C CGI!\n");
	return 0;
}
